// A simple program that displays hello world to the screen 
// Jing Yeh
// YHXJIN001 
// 29 July 2023

public class HelloWorld{
   public static void main(String[] args){
      System.out.println("Hello World");
   }
}  