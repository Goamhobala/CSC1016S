/* Jing Yeh
*  YHXJIN001
*  8 August 2023
*/ 
public class Seller {
   public String ID;
   public String Name;
   public String Location;
   public String Product;
   public Money unit_price;
   public int number_of_units;
   
//    Seller(String ID, String Name, String Location, String Product, String unit_price, int number_of_units){
//       this.ID = ID;
//       this.Name = Name;
//       this.Location = Location;
//       this.Product = Product;
//       this.unit_price = unit_price;
//       this.number_of_units = number_of_units;
//    }
}